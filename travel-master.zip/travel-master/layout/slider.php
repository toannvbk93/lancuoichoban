<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="slider">
			<div class="flexslider">
				<ul class="slides">
					<li><img src="asset/image/slides/slider2.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider3.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider4.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider5.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider6.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider7.jpg" class="img-responsive" /> </li>
					<li><img src="asset/image/slides/slider8.jpg" class="img-responsive" /> </li>
				</ul>
					
			</div>
			</div>
		</div>

	</div>
</div>		

