<?php require_once('layout/head.php');?>
<?php require_once('layout/header.php'); ?>
<?php require_once('layout/navigation.php'); ?>
<?php require_once('contact.php'); ?>
<?php require_once('layout/footer.php'); ?>