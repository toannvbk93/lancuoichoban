<div class="row">
    <div class="col-lg-12">
            <h1 class="page-header"><?php echo $title ?></h1>
            <?php require_once('template/current_possition.php') ?>
    </div>
</div>