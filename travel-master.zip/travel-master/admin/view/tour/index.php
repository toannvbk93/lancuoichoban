<?php require_once('template/header.php'); ?>
	<div id="wrapper">
    	<div id="page-wrapper">
			<div class="container-fluid">
				<?php require_once('template/page_header.php'); ?>
				<?php require_once('view/tour/tour_table.php'); ?>
			</div>
		</div>
	</div>